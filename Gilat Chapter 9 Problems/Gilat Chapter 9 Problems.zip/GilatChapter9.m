% GilatChapter9.m
% Noah Ruderman
% This script file includes all the problems from Chapter 9 of MATLAB: An 
% Introduction with Applications by Amos Gilat
% Chapter 9: Three-Dimensional Plots
% 5.21.11

close all
clear
clc
format loose

%% Problem 1
% disp('Problem 1')
t = 0:.5:30;
x = (1 + 0.1*t).*(cos(t));
y = x;
z = 0.2*sqrt(t);

figure()
plot3(x,y,z)
xlabel('x'); ylabel('y'); zlabel('z')
title('Problem 1 Graph')
grid on





%% Problem 2
% disp('Problem 2')
a = 10;     % m     semimajor axis
b = 5;      % m     semiminor axis
h = 6;      % m
n = 4;      % revolutions

t = linspace(0, 2*pi*n, 200);

epsilon = sqrt(1 - b^2/a^2);
r = b./sqrt(1 - epsilon^2*cos(t).^2);

x = r.*cos(t);
y = r.*sin(t);
z = h*t/(2*pi*n);

figure()
plot3(x,y,z,'linewidth', 2, 'color', 'black')
xlabel('x (m)'); ylabel('y (m)'); zlabel('z (m)')
title('Problem 2 Graph')
grid on





%% Problem 3
% disp('Problem 3')

[t q] = ode45(@dladderdt, [0 10], [8 0 0]);

[X Y Z] = meshgrid(q(1:end,1), q(1:end,2), q(1:end,3));

figure()
stem3(q(1:end,1), q(1:end,2), q(1:end,3),'fill')
grid off
box off
xlabel('x (m)'); ylabel('y (m)'); zlabel('z (m)')
title('Problem 3 Graph')





%% Problem 4
% disp('Problem 4')
x = -2:.1:2;
y = x;
[X Y] = meshgrid(x,y);

Z = 4*sqrt(X.^2/2 + Y.^2/2 + 1);

figure()
subplot(2,2,1)
surf(X,Y,Z)
xlabel('x'); ylabel('y'); zlabel('z')
title('Problem 4 Graph Surface Plot')

subplot(2,2,2)
contour3(X,Y,Z)
xlabel('x'); ylabel('y'); zlabel('z')
title('Problem 4 Graph Contour Plot')





%% Problem 5
% disp('Problem 5')
k = 0.01;   % in^(-1)
x = -3:.1:3;
y = x;

[X, Y] = meshgrid(x,y);
W = k*(X.^2 - Y.^2);

figure()
surf(X,Y,W)
xlabel('x (in)'); ylabel('y (in)'); zlabel('w (in)');
title('Problem 5 Graph')





%% Problem 6
% disp('Problem 6')
x = 0:60;
y = x;

[X, Y] = meshgrid(x,y);
Z = sin(2*pi*X/60).*sin(3*pi*Y/60);

figure()
surf(X,Y,Z)
xlabel('x'); ylabel('y'); zlabel('z');
title('Problem 6 Graph')





%% Problem 7
% disp('Problem 7')
R = 0.08206;    % L atm / mole K
n = 1.5;        % moles
a = 1.39;       % L^2 atm / mole^2
b = 0.03913;    % L / mole

v = linspace(0.3, 1.2, 100);
t = linspace(273, 473, 100);

[V T] = meshgrid(v,t);

P = n*R*T./(V - b) - n^2*a./(V.^2);

figure()
mesh(V,T,P)
xlabel('V (L)'); ylabel('T (K)'); zlabel('P (Pa)');
title('Problem 7 Graph')





%% Problem 8
% disp('Problem 8')
R = 8.31;   % J / mole K
M_O2 = 0.032;   % kg / mole

v = linspace(0, 1000, 50);
t = linspace(70, 320, 50);

[V T] = meshgrid(v,t);
P = 4*pi*(M_O2./(2*pi*R*T)).^(3/2).*V.^2.*exp(-M_O2*V.^2./(2*R*T));

figure()
surf(V,T,P)
xlabel('V (L)'); ylabel('T (K)'); zlabel('P (Pa)');
title('Problem 8 Graph')





%% Problem 9
% disp('Problem 9')
t = linspace(80,105,50);
r_h = linspace(30,90,50);

[T R_H] = meshgrid(t,r_h);

HI = -42.379 + 2.04901523*T + 10.14333127*R_H - 0.22475541*T.*R_H ...
    - 6.83783*10^(-3)*T.^2 - 5.481717*10^(-2)*R_H.^2 ...
    + 1.22874*10^(-3)*T.^2.*R_H + 8.5282*10^(-4)*T.*R_H.^2 ...
    - 1.99*10^(-6)*T.^2.*R_H.^2;

figure()
surf(T, R_H, HI)
xlabel('T (Fahrenheit)'); ylabel('R_H (%)'); zlabel('HI');
title('Problem 9 Graph')





% Problem 10
disp('Problem 10')
C = 15*10^(-6);     % F
L = 240*10^(-3);    % H
v_m = 24;           % V



% disp('a.')
f = linspace(60, 110, 50);
r = linspace(10, 40, 50);
omega_d = 2*pi*f;

[OMEGA_D, R] = meshgrid(omega_d, r);
I = v_m./sqrt(R.^2 + (OMEGA_D*L - 1./(OMEGA_D*C)).^2);

figure()
subplot(2,2,1)
surf(OMEGA_D/(2*pi), R, I)
xlabel('Frequency (Hz)'); ylabel('R (\Omega)'); zlabel('I (Amps)');
title('Problem 10 Graph Part A')



disp('b.')
subplot(2,2,2)
surf(OMEGA_D/(2*pi), R, I)
xlabel('Frequency (Hz)'); ylabel('R (\Omega)'); zlabel('I (Amps)');
title('Problem 10 Graph Part B')
view(0,0)

fprintf('\tI estimate that the natural frequency of the circuit is %.4f s^(-1)\n', 525/(2*pi))
fprintf('\tCompare this to the calculated value of %.4f s^(-1)\n\n\n', 1/(2*pi*sqrt(L*C)))





%% Problem 11
% disp('Problem 11')
h = 40;     % mm
b = 30;     % mm
y_F = -15;  % mm
z_F = -10;  % mm
F = -250000;    % N
I_zz = 1/12*b*h^3;
I_yy = 1/12*h*b^3;

y = linspace(-50,50,50);
z = linspace(-50,50,50);

[Y Z] = meshgrid(y,z);
SIGMA_xx = F/(h*b) + F*z_F*Z/I_yy + F*y_F*Y/I_zz;

figure()
surf(Y,Z,SIGMA_xx)
xlabel('y (mm)'); ylabel('z (mm)'); zlabel('\sigma_x_x')
title('Problem 11 Graph')





%% Problem 12
% disp('Problem 12')
G = 27.7*10^9;  % Pa
b = 0.286*10^(-6);  % m
v = 0.334; 

x = linspace(-5*10^(-9), 5*10^(-9), 50);
y = linspace(-5*10^(-9), -1*10^(-9), 50);

[X Y] = meshgrid(x,y);
SIGMA_xx = -G*b/(2*pi*(1 - v))*Y.*(3*X.^2 + Y.^2)./(X.^2 + Y.^2).^2;
SIGMA_yy =  G*b/(2*pi*(1 - v))*Y.*(X.^2 - Y.^2)./(X.^2 + Y.^2).^2;
TAU_xy =  G*b/(2*pi*(1 - v))*X.*(X.^2 - Y.^2)./(X.^2 + Y.^2).^2;

figure()
subplot(2,2,1)
surf(X,Y,SIGMA_xx)
xlabel('x (m)'); ylabel('y (m)'); zlabel('\sigma_x_x')
title('Problem 12 Graph \sigma_x_x')

subplot(2,2,2)
surf(X,Y,SIGMA_yy)
xlabel('x (m)'); ylabel('y (m)'); zlabel('\sigma_y_y')
title('Problem 12 Graph \sigma_y_y')

subplot(2,2,3)
surf(X,Y,TAU_xy)
xlabel('x (m)'); ylabel('y (m)'); zlabel('\tau_x_y')
title('Problem 12 Graph \tau_x_y')





%% Problem 13
% disp('Problem 13')
I_s = 10^(-12);     % A
q = 1.6*10^(-19);   % C
k = 1.38*10^(-23);  % J / K

v_d = linspace(0,.4,50);
t = linspace(290,320,50);

[V_D T] = meshgrid(v_d, t);

I = I_s*(exp(q*V_D./(k*T)) - 1);

figure()
surf(V_D, T, I)
xlabel('V_d (V)'); ylabel('T (K)'); zlabel('I (Amps)');
title('Problem 13 Graph')





%% Problem 14
% disp('Problem 14')
x = linspace(-3,3,50);
y = linspace(-3,3,50);

[X Y] = meshgrid(x,y);

Psi = Y - Y./(X.^2 + Y.^2);

[Xc Yc Zc] = cylinder(1);

figure()
contour(X,Y,Psi,100)
hold on
contour(Xc,Yc,Zc,1,'color', 'black','linewidth',2);
hold off
xlabel('x'); ylabel('y');
title('Problem 14 Graph')





%% Problem 15
% disp('Problem 15')
r = 0.1;    % s^(-1)
N_0 = 10;

t = linspace(0,100,50);
N_inf = linspace(100,1000,50);

[T, N_INF] = meshgrid(t, N_inf);

NT = N_INF./(1 + (N_INF/N_0 - 1)*exp(-r*T));

figure()
surf(T, N_INF, NT)
xlabel('t (s)'); ylabel('N_\infty'); zlabel('N(t)');
title('Problem 15 Graph')




